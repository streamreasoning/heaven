package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.esper;

public class PropertyNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PropertyNotFoundException(String msg) {
		super(msg);
	}
}
