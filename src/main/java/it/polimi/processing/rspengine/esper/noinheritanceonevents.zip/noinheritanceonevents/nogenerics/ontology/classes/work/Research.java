package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.ontology.classes.work;

public class Research extends Work {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4977920284135679107L;

	public Research(String object) {
		super(object);
	}

	public Research() {
		super("http://swat.cse.lehigh.edu/onto/univ-bench.owl#Research");
	}
}
