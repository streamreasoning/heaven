package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.ontology.classes.publication;

public class Software extends Publication {

	/**
	 * 
	 */
	private static final long serialVersionUID = -112003647090572280L;

	public Software(String object) {
		super(object);
	}

	public Software() {
		super("http://swat.cse.lehigh.edu/onto/univ-bench.owl#Software");
	}
}
