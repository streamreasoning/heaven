package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.ontology.classes.organization;

public class Institute extends Organization {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9169016328730455166L;

	public Institute(String object) {
		super(object);
	}

	public Institute() {
		super("http://swat.cse.lehigh.edu/onto/univ-bench.owl#Institute");
	}

}
