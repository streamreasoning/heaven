package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.ontology.classes.publication;

public class Manual extends Publication {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1727776952651276346L;

	public Manual(String object) {
		super(object);
	}

	public Manual() {
		super("http://swat.cse.lehigh.edu/onto/univ-bench.owl#Manual");
	}
}
