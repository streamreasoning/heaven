package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.ontology.classes.organization;

public class Program extends Organization {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3193078281216801125L;

	public Program(String object) {
		super(object);
	}

	public Program() {
		super("http://swat.cse.lehigh.edu/onto/univ-bench.owl#Program");
	}
}
