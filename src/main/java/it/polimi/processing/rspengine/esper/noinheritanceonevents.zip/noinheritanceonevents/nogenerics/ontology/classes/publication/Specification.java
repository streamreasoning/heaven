package it.polimi.processing.rspengine.esper.noinheritanceonevents.nogenerics.ontology.classes.publication;

public class Specification extends Publication {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5490016594532592302L;

	public Specification(String object) {
		super(object);
	}

	public Specification() {
		super("http://swat.cse.lehigh.edu/onto/univ-bench.owl#Specification");
	}
}
